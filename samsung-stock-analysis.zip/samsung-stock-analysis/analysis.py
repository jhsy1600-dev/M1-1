import os
import pandas as pd
import yfinance as yf

# 1. 폴더 생성
os.makedirs("data", exist_ok=True)
os.makedirs("images", exist_ok=True)

# 2. 삼성전자 주가 데이터 다운로드
ticker = "005930.KS"

df = yf.download(
    ticker,
    start="2023-01-01",
    end="2025-01-01",
    auto_adjust=False,
    progress=False
)

# 3. 혹시 컬럼이 복잡하게 받아지는 경우 정리
if isinstance(df.columns, pd.MultiIndex):
    df.columns = df.columns.get_level_values(0)

# 4. 날짜를 컬럼으로 변환
df = df.reset_index()

# 5. CSV 파일로 저장
save_path = "data/samsung_2023_2024.csv"
df.to_csv(save_path, index=False, encoding="utf-8-sig")

# 6. 확인 출력
print("삼성전자 주가 데이터 저장 완료!")
print("저장 위치:", save_path)
print("데이터 개수:", len(df))
print(df.head())